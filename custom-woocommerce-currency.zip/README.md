# Custom WooCommerce Currency Switcher

A comprehensive WordPress plugin that allows users to switch between multiple currencies on a WooCommerce store. Administrators can easily manage currencies through the WordPress dashboard.

## Features

✅ **Admin Dashboard Management**
- Add, edit, and delete currencies
- Set currency name, symbol, code, and multiplier (exchange rate)
- Mark a currency as default
- Enable/disable currencies

✅ **Frontend Currency Switcher**
- Fixed position currency selector widget
- Users can switch currencies on the fly
- Session-based currency selection
- Automatic page reload to update all prices

✅ **Price Conversion**
- Automatic conversion for all product prices
- Works on single product pages
- Updates cart prices
- Updates checkout prices
- Maintains consistency across the entire site

✅ **Email Integration**
- Converted prices appear in WooCommerce emails
- Currency information displayed in order emails
- Shows exchange rate used

## Installation

1. Upload the `custom-woocommerce-currency` folder to `/wp-content/plugins/`
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Navigate to **Currency Switcher** in the admin menu
4. Add your currencies with their multipliers

## Requirements

- WordPress 5.8 or higher
- WooCommerce 5.0 or higher
- PHP 7.4 or higher

## Usage

### Adding a Currency

1. Go to **Currency Switcher > Add New** in WordPress admin
2. Fill in the currency details:
   - **Currency Name**: Full name (e.g., "US Dollar")
   - **Currency Symbol**: Symbol to display (e.g., "$")
   - **Currency Code**: 3-letter ISO code (e.g., "USD")
   - **Multiplier**: Exchange rate from default currency
   - **Set as Default**: Check to make this the default currency
   - **Status**: Active or Inactive
3. Click **Add Currency**

### Setting the Multiplier

The multiplier is the conversion rate from your default currency. 

**Examples:**
- If your default is USD and 1 USD = 0.85 EUR, enter `0.85` for EUR
- If your default is USD and 1 USD = 110 JPY, enter `110` for JPY
- If your default is EUR and 1 EUR = 1.18 USD, enter `1.18` for USD

### Frontend Usage

Users will see a currency switcher widget on the right side of the page:
1. Click on the currency selector
2. Choose their preferred currency
3. Prices update automatically across the site

## File Structure

```
custom-woocommerce-currency/
├── custom-woocommerce-currency.php  (Main plugin file)
├── assets/
│   ├── admin.js                     (Admin JavaScript)
│   ├── admin.css                    (Admin styles)
│   ├── frontend.js                  (Frontend JavaScript)
│   └── frontend.css                 (Frontend styles)
└── README.md                        (This file)
```

## How It Works

### Database
Creates a custom table `wp_custom_currencies` to store:
- Currency name
- Currency symbol
- Currency code
- Multiplier (exchange rate)
- Default flag
- Active/inactive status

### Session Management
Uses PHP sessions to store the user's selected currency preference during their visit.

### Price Conversion
Hooks into WooCommerce filters:
- `woocommerce_product_get_price`
- `woocommerce_product_get_regular_price`
- `woocommerce_product_get_sale_price`
- Product variations
- Cart items
- Order totals

### Currency Symbol
Changes the currency symbol and code displayed throughout the site based on user selection.

## Customization

### Styling the Switcher

Edit `assets/frontend.css` to customize the currency switcher appearance:

```css
.cwc-currency-switcher {
    position: fixed;
    top: 100px;  /* Adjust position */
    right: 20px;
    /* Add your custom styles */
}
```

### Changing Switcher Position

You can modify the position via CSS or by editing the display function in the main plugin file.

## Troubleshooting

**Currency switcher not appearing?**
- Ensure WooCommerce is active
- Check that you have active currencies in the database
- Clear browser cache

**Prices not converting?**
- Verify multiplier values are correct
- Check that the currency is marked as "Active"
- Ensure session is started (check PHP session settings)

**Admin page not loading?**
- Check user has `manage_options` capability
- Verify database table was created on activation

## Hooks & Filters

Developers can extend functionality using these hooks:

```php
// Modify currency before display
add_filter('cwc_current_currency', function($currency) {
    // Modify currency object
    return $currency;
});

// Modify price conversion
add_filter('cwc_convert_price', function($price, $multiplier) {
    // Custom conversion logic
    return $price * $multiplier;
}, 10, 2);
```

## Security

- Nonce verification on all AJAX requests
- Capability checks for admin functions
- SQL injection prevention using $wpdb prepared statements
- XSS protection with proper escaping
- CSRF protection on forms

## Support

For issues, feature requests, or contributions, please contact the plugin author.

## Changelog

### Version 1.0.0
- Initial release
- Admin dashboard for currency management
- Frontend currency switcher
- Price conversion for products, cart, checkout
- Email integration
- Session-based currency selection

## License

This plugin is provided as-is for use with WordPress and WooCommerce.

## Credits

Developed with ❤️ for WooCommerce store owners who need multi-currency support.
#   C u s t o m - W o o C o m m e r c e - C u r r e n c y - S w i t c h e r  
 